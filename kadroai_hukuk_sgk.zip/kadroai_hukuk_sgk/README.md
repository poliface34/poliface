# KadroAI `@HukukSGK` — `v1.0.5` (Katı ITU-T X.690 DER Kanonikliği, L5/L6 Özerk Norm Katmanları, 5070 Sayılı Kanun NES & CAdES/XAdES ve Marka Geçişi)

`@HukukSGK`, **KadroAI** platformunun (**`@KadroAI`** koordinatörü altında görev yapan) **Türkiye İş Hukuku & Sosyal Güvenlik Mevzuatı** uzman yapay zekâ ajanıdır.
Bağımsız incelemeden geçerek teknik kabul alan **`v1.0.4.5`** (ve dondurulmuş `v1.0.2c.6`–`v1.0.4.4`) temelleri üzerine kurulu **`v1.0.5`** sürümü; **`engine/esign5070/xmldsig.py`** dosyasını **`v1.0.4.4`/`v1.0.4.5` ile bayt düzeyinde birebir (`byte-identical`)** ve tüm OpenSSL 3 kriptografik/CA zinciri doğrulamalarını eksiksiz koruyarak onaylı dört mimari kararı uygular:

1. **Karar 1 — Katı ITU-T X.690 DER Kanonikliği ([`engine/esign5070/x509_metadata.py`](engine/esign5070/x509_metadata.py)):**
   - Salt-okunur X.509 metadata okuyucusu belirsiz uzunluk (`0x80`), ayrılmış (`0xFF`), minimal olmayan uzun-form (`<128` veya önde sıfır), kanonik olmayan yüksek-etiket, `0x00`/`0xFF` dışı `BOOLEAN`, minimal olmayan `INTEGER`, önde `0x80` bulunan `OID` alt tanımlayıcıları, geçersiz `BIT STRING` kullanılmayan/dolgu bitleri, geçersiz RFC 5280 `UTCTime`/`GeneralizedTime` tarihleri, fazla son baytlar ve **`MAX_ASN1_DEPTH = 32`** derinlik sınırını aşan yapıları `DerParseError` ile fail-closed reddeder; asla kısmi metadata döndürmez.
   - PEM/Base64 çözümlemesi yalnızca tekil ve temiz sertifika bloğunu kabul eder; çoklu blok, beklenmeyen ek metin veya bozuk Base64 reddedilir.
   - Önbellek anahtarı `(sha256, len)` yanında ham DER bayt eşitliğini (`hit[0] == raw`) zorunlu kılar.
   - **W3C C14N / XMLDSig dokunulmazlığı:** [`engine/esign5070/xmldsig.py`](engine/esign5070/xmldsig.py) dosyası `v1.0.4.4` ve `v1.0.4.5` ile **%100 bayt düzeyinde özdeştir**; tüm OpenSSL 3 imza/CA/OCSP/CRL/TSA doğrulamaları korunmuştur.
2. **Karar 2 — L5 Kurumsal İK Prosedürleri & L6 Özerk Normlar Mimarisi ([`engine/autonomous_norms.py`](engine/autonomous_norms.py)):**
   - Resmî L1–L4 mevzuat çekirdeğinden (`74/74` dokunulmadı) kesin ayrıştırılmış **5 L5 Kurumsal İK Prosedürü** (`rag_kb/05_ik_prosedurleri/`, `10` kural) ve **4 ayrı L6 Özerk Norm Modülü** (`rag_kb/06_tis_sozlesme_ve_isyeri_uygulamalari/`, `9` kural — TİS, bireysel iş sözleşmesi, işyeri iç yönetmeliği ve yerleşik işyeri uygulaması ayrı dosyalar ve ayrı `autonomous_source_kind` türleriyle).
   - **Tekil `priority: 8` yasağı:** Her kural 7 zorunlu alan taşır (`norm_type`, `legal_basis_ids`, `source_document_id`, `adoption_status`, `employee_favorable_check`, `conflict_resolution`, `human_review_required`).
   - **Kabul edilmemiş şablon güvencesi:** Yerleşik tüm şablonlar `REFERENCE_TEMPLATE_PENDING_COMPANY_ADOPTION` durumunda başlar ve kurum onayı olmadan asla bağlayıcı şirket politikası gibi sunulmaz (`binding_company_policy: false`, `human_review_required: true`).
   - **Bağımsız L5/L6 Denetim Defteri:** [`config/autonomous_norms_audit_log.json`](config/autonomous_norms_audit_log.json) tüm L5/L6 kayıtlarını resmî `74/74` `config/verification_audit_log.json` defterinden ayrı izler.
3. **Karar 3 — Geriye Uyumlu `KadroAI` Marka Geçişi:**
   - Ürün: **`KadroAI`** | Koordinatör: **`@KadroAI`** | Uzman: **`@HukukSGK`** | Paket: **`kadroai_hukuk_sgk_v1.0.5.zip`** (kök klasör: `kadroai_hukuk_sgk/`) | HTTP `User-Agent`: `KadroAI-HukukSGK/1.0.5 (SourceAcquisition)`.
   - Yeni `v1.0.5` servis kimlikleri (`KADROAI_CADES_XADES_5070_VERIFIER_V105`, `KADROAI_SSCD_CONTROL_EVIDENCE_VERIFIER_V105`, `KADROAI-L5-*`, `KADROAI-L6-*`, `CHK-RELEASE-1.0.5-20261124`) `KadroAI` kimliğiyle üretilirken tarihsel denetim/imza kimlikleri (`CALISORA-HUKUK-01`, `CALISORA-LEDGER-SEALER-01`, `AUD-20261120-*`, tarihsel JCS şema belirteçleri) geriye uyumluluk için korunur.
4. **Karar 4 — Regresyon Korunumu ve Fail-Closed Üretim/5070 Kapıları:**
   - Önceki `224` testin tamamı korunmuş, üzerine kapsamlı `v1.0.5` DER + L5/L6 + `KadroAI` test paketi ([`tests/test_v105_der_l5_l6_and_kadroai.py`](tests/test_v105_der_l5_l6_and_kadroai.py)) eklenmiştir.
   - Canlı dış servisler ve harici hukuk müşaviri imzası doğrulanmadan **`production_use_authorized: false`**, **`qualified_e_signature_5070_production_ready: false`**, **`qualified_e_signature_5070_equivalent: false`** ve **`NOT_CONFIGURED`** kilitleri kesinlikle kapalı kalır.

Ayrıntılı mimari dokümanlar:
- [`docs/v1.0.5_kadroai_der_and_l5_l6_architecture.md`](docs/v1.0.5_kadroai_der_and_l5_l6_architecture.md)
- [`docs/v1.0.4_law5070_nes_cades_xades_architecture.md`](docs/v1.0.4_law5070_nes_cades_xades_architecture.md)
- [`docs/v1.0.3_gcp_production_trust_root_architecture.md`](docs/v1.0.3_gcp_production_trust_root_architecture.md)

---

## L1–L4 Resmî Çekirdek (`74/74`) ve Ayrık L5/L6 Özerk Norm Envanteri

| Katman | Toplam Kayıt | Tam Doğrulanmış / Durum | İnceleme / Kabul Bekleyen | Mülga |
|---|---:|---:|---:|---:|
| **Resmî Mevzuat Kaynakları** (`config/legal_sources_registry.json`) | **30** | **28** (`VERIFIED`) | **1** (`GIB-TEBLIG-332-20251231`) | **1** (`RG-9368-20241228`) |
| **L4 — Yargıtay İçtihatları** (`config/yargitay_precedents.json`) | **5** | **4** (`VERIFIED`) | **1** (`YIBBGK-2021-8-2026-1`) | **0** |
| **L1 — Temel Kanun Bilgi Kartları** (`rag_kb/01_kanunlar/` — 9 dosya) | **25** | **25** (`VERIFIED`) | **0** | **0** |
| **L2 — Yönetmelik Bilgi Kartları** (`rag_kb/02_yonetmelikler/` — 6 dosya) | **7** | **7** (`VERIFIED`) | **0** | **0** |
| **L3 — Tebliğ, CK & SGK Kartları** (`rag_kb/03_teblig_ve_genelgeler/` — 7 dosya) | **7** | **6** (`VERIFIED`) | **1** (`CARD-GIB-332-2026-TARIFE`) | **0** |
| **Resmî L1–L4 Denetim Defteri Toplamı** (`config/verification_audit_log.json`) | **74** | **70** | **3** | **1** |
| **L5 — Kurumsal İK Prosedürleri** (`rag_kb/05_ik_prosedurleri/` — 5 dosya) | **5 modül / 10 kural** | **0** (bağlayıcı kabul yok) | **5 modül** (`REFERENCE_TEMPLATE_PENDING_COMPANY_ADOPTION`) | **0** |
| **L6 — Özerk Normlar** (`rag_kb/06_tis_sozlesme_ve_isyeri_uygulamalari/` — 4 dosya) | **4 modül / 9 kural** | **0** (bağlayıcı kabul yok) | **4 modül** (`REFERENCE_TEMPLATE_PENDING_COMPANY_ADOPTION`) | **0** |
| **Bağımsız L5/L6 Denetim Defteri** (`config/autonomous_norms_audit_log.json`) | **9 modül / 19 kural** | **0** (kurum kabulü bekliyor) | **9 modül** | **0** |

- **JSON Schema Draft 2020-12:** **`13`** şema (`11` L1–L4/Güven Kökü/5070 şeması + `2` yeni L5/L6 özerk norm şeması).
- **Yapılandırma Dosyaları (`config/`):** Toplam **`9`** JSON dosyası (`6` adedi özel Draft 2020-12 şemayla doğrulanan kayıt/yapılandırma dosyası + `3` adedi motor ve denetim doğrulayıcılarıyla doğrulanan `knowledge_taxonomy.json`, `verification_audit_log.json` ve `autonomous_norms_audit_log.json`).
- **Arşivli Dinî Bayram Takvimi & Hash Zinciri:** `TR-UBGT-RELIGIOUS-HOLIDAY-CALENDAR-2024-2027` (`v1.0.5`, sürüm checkpoint'i `CHK-RELEASE-1.0.5-20261124`).

---

## Bağımsız Test, Canlı Prob ve Doğrulama Komutları

```bash
# 1. Tam tek süreçli regresyon paketi (tüm önceki 224 test + yeni v1.0.5 DER/L5/L6/KadroAI testleri)
python3 -m unittest discover -s tests -v

# 2. Gerçek canlı dış servis yapılandırma probu (5 durumlu dürüst 5070 + GCP/TSA/WORM probu)
python3 -W error -m engine.trust_root.integration_probe
```
